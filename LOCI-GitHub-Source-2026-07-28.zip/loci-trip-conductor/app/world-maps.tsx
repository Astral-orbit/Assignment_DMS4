"use client";

import { useEffect, useRef, useState } from "react";
import type { Map as MapLibreMap } from "maplibre-gl";

type Lang = "KR" | "EN";
type CountryOption = { en: string; ko: string; code: string; mapName?: string };

const rasterStyle = {
  version: 8 as const,
  sources: {
    osm: {
      type: "raster" as const,
      tiles: ["https://tile.openstreetmap.org/{z}/{x}/{y}.png"],
      tileSize: 256,
      attribution: "© OpenStreetMap contributors",
    },
  },
  layers: [{ id: "osm", type: "raster" as const, source: "osm" }],
};

export function WorldCommunityMap({
  lang,
  selectedCountry,
  selectedCode,
  onSelectCountry,
}: {
  lang: Lang;
  selectedCountry: string;
  selectedCode: string;
  onSelectCountry: (country: string, code: string) => void;
}) {
  const container = useRef<HTMLDivElement>(null);
  const mapRef = useRef<MapLibreMap | null>(null);
  const onSelectRef = useRef(onSelectCountry);
  const selectedRef = useRef(selectedCountry);
  const selectedCodeRef = useRef(selectedCode);
  const [countries, setCountries] = useState<CountryOption[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => { onSelectRef.current = onSelectCountry; }, [onSelectCountry]);
  useEffect(() => { selectedRef.current = selectedCountry; }, [selectedCountry]);
  useEffect(() => { selectedCodeRef.current = selectedCode; }, [selectedCode]);

  useEffect(() => {
    if (!container.current || mapRef.current) return;
    let cancelled = false;

    (async () => {
      const maplibregl = await import("maplibre-gl");
      const response = await fetch("/world-countries.geojson");
      const geojson = await response.json() as {
        features: Array<{ properties: { ADMIN?: string; NAME_KO?: string; ISO_A2?: string } }>;
      };
      if (cancelled || !container.current) return;

      const boundaries = new Map(geojson.features.map(feature => [feature.properties.ISO_A2, {
        mapName: feature.properties.ADMIN,
        ko: feature.properties.NAME_KO,
      }]));
      const boundariesByName = new Map(geojson.features.map(feature => [feature.properties.ADMIN, {
        mapName: feature.properties.ADMIN,
        ko: feature.properties.NAME_KO,
      }]));
      const enNames = new Intl.DisplayNames(["en"], { type: "region" });
      const koNames = new Intl.DisplayNames(["ko"], { type: "region" });
      const options: CountryOption[] = [];
      for (let first = 65; first <= 90; first += 1) {
        for (let second = 65; second <= 90; second += 1) {
          const code = String.fromCharCode(first, second);
          const en = enNames.of(code);
          if (!en || en === code) continue;
          const boundary = boundaries.get(code) || boundariesByName.get(en);
          options.push({ code, en, ko: boundary?.ko || koNames.of(code) || en, mapName: boundary?.mapName });
        }
      }
      options.sort((a, b) => a.en.localeCompare(b.en));
      setCountries(options);

      const map = new maplibregl.Map({
        container: container.current,
        style: rasterStyle,
        center: [12, 18],
        zoom: 1.25,
        minZoom: 1,
        maxZoom: 7,
      });
      mapRef.current = map;
      map.addControl(new maplibregl.NavigationControl({ showCompass: false }), "top-right");
      map.on("load", () => {
        if (cancelled) return;
        map.addSource("countries", { type: "geojson", data: geojson as never, generateId: true });
        map.addLayer({
          id: "countries-fill",
          type: "fill",
          source: "countries",
          paint: {
            "fill-color": "#7259ff",
            "fill-opacity": ["case", ["any", ["==", ["get", "ISO_A2"], selectedCodeRef.current], ["==", ["get", "ADMIN"], selectedRef.current]], 0.34, 0.035],
          },
        });
        map.addLayer({
          id: "countries-line",
          type: "line",
          source: "countries",
          paint: { "line-color": "rgba(76,58,170,.55)", "line-width": 0.7 },
        });
        map.on("mouseenter", "countries-fill", () => { map.getCanvas().style.cursor = "pointer"; });
        map.on("mouseleave", "countries-fill", () => { map.getCanvas().style.cursor = ""; });
        map.on("click", "countries-fill", (event) => {
          const country = event.features?.[0]?.properties?.ADMIN as string | undefined;
          const code = event.features?.[0]?.properties?.ISO_A2 as string | undefined;
          const matched = options.find(option => option.mapName === country || option.en === country);
          if (country) onSelectRef.current(country, matched?.code || (code && code !== "-99" ? code : "--"));
        });
        setReady(true);
      });
    })().catch(() => setReady(false));

    return () => {
      cancelled = true;
      mapRef.current?.remove();
      mapRef.current = null;
    };
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    if (!map || !ready || !map.getLayer("countries-fill")) return;
    map.setPaintProperty("countries-fill", "fill-opacity", ["case", ["any", ["==", ["get", "ISO_A2"], selectedCode], ["==", ["get", "ADMIN"], selectedCountry]], 0.34, 0.035]);
  }, [selectedCountry, selectedCode, ready]);

  return (
    <section className="real-world-map glass-strong">
      <div className="world-map-toolbar glass">
        <label htmlFor="country-select">{lang === "KR" ? "국가 선택" : "Choose a country"}</label>
        <select id="country-select" value={selectedCode} onChange={(e) => {
          const country = countries.find(option => option.code === e.target.value);
          if (country) onSelectCountry(country.mapName || country.en, country.code);
        }}>
          {countries.map((country) => <option key={`${country.code}-${country.en}`} value={country.code}>{lang === "KR" ? country.ko : country.en}</option>)}
        </select>
        <span>{countries.length ? `${countries.length} ${lang === "KR" ? "개 국가·지역" : "countries & territories"}` : (lang === "KR" ? "국가 목록 불러오는 중" : "Loading countries")}</span>
      </div>
      <div ref={container} className="map-host world-map-host" aria-label={lang === "KR" ? "국가를 선택할 수 있는 세계지도" : "Interactive world map for country selection"} />
      {!ready && <div className="map-loading">{lang === "KR" ? "세계지도를 불러오는 중…" : "Loading the world map…"}</div>}
      <div className="map-instruction glass">{lang === "KR" ? "지도를 확대하고 국가 경계를 클릭하세요" : "Zoom the map and click any country boundary"}</div>
    </section>
  );
}

export function LocationMap({
  center,
  label,
  lang,
  routeCoordinates = [],
  stops = [],
  onSelectStop,
}: {
  center?: [number, number];
  label: string;
  lang: Lang;
  routeCoordinates?: Array<[number, number]>;
  stops?: Array<{ id?: string; name: string; coordinates: [number, number] }>;
  onSelectStop?: (id: string) => void;
}) {
  const container = useRef<HTMLDivElement>(null);
  const onSelectStopRef = useRef(onSelectStop);

  useEffect(() => { onSelectStopRef.current = onSelectStop; }, [onSelectStop]);

  useEffect(() => {
    if (!container.current || !center) return;
    let map: MapLibreMap | null = null;
    let cancelled = false;
    (async () => {
      const maplibregl = await import("maplibre-gl");
      if (cancelled || !container.current) return;
      map = new maplibregl.Map({
        container: container.current,
        style: rasterStyle,
        center,
        zoom: 11.8,
        minZoom: 2,
        maxZoom: 17,
      });
      map.addControl(new maplibregl.NavigationControl({ showCompass: false }), "top-right");
      map.on("load", () => {
        if (!map) return;
        const line = routeCoordinates.length >= 2 ? routeCoordinates : [];
        const pointFeatures = stops.map((stop, index) => ({
          type: "Feature" as const,
          properties: { kind: "stop", id: stop.id || "", index: index + 1, name: stop.name },
          geometry: { type: "Point" as const, coordinates: stop.coordinates },
        }));
        if (!line.length && !pointFeatures.length) return;
        map.addSource("trip-route", {
          type: "geojson",
          data: {
            type: "FeatureCollection",
            features: [
              ...(line.length ? [{ type: "Feature" as const, properties: { kind: "route" }, geometry: { type: "LineString" as const, coordinates: line } }] : []),
              ...pointFeatures,
            ],
          },
        });
        if (line.length) map.addLayer({ id: "trip-route-line", type: "line", source: "trip-route", filter: ["==", ["get", "kind"], "route"], paint: { "line-color": "#7259ff", "line-width": 5, "line-opacity": .9 } });
        if (pointFeatures.length) {
          map.addLayer({ id: "trip-route-points", type: "circle", source: "trip-route", filter: ["==", ["get", "kind"], "stop"], paint: { "circle-radius": 8, "circle-color": "#10231f", "circle-stroke-color": "#fff", "circle-stroke-width": 3 } });
          map.addLayer({ id: "trip-route-labels", type: "symbol", source: "trip-route", filter: ["==", ["get", "kind"], "stop"], layout: { "text-field": ["to-string", ["get", "index"]], "text-size": 10 }, paint: { "text-color": "#fff" } });
          map.on("mouseenter", "trip-route-points", (event) => {
            map!.getCanvas().style.cursor = "pointer";
            const feature = event.features?.[0];
            if (!feature || feature.geometry.type !== "Point") return;
            new maplibregl.Popup({ closeButton: false, closeOnClick: false, offset: 13, className: "place-map-popup" })
              .setLngLat(feature.geometry.coordinates as [number, number])
              .setText(String(feature.properties?.name || ""))
              .addTo(map!);
          });
          map.on("mouseleave", "trip-route-points", () => {
            map!.getCanvas().style.cursor = "";
            document.querySelectorAll(".place-map-popup").forEach(element => element.remove());
          });
          map.on("click", "trip-route-points", (event) => {
            const id = String(event.features?.[0]?.properties?.id || "");
            if (id) onSelectStopRef.current?.(id);
          });
        }
        const boundsCoordinates = line.length ? line : stops.map(stop => stop.coordinates);
        if (boundsCoordinates.length > 1) {
          const bounds = boundsCoordinates.reduce((bounds, coordinate) => bounds.extend(coordinate), new maplibregl.LngLatBounds(boundsCoordinates[0], boundsCoordinates[0]));
          map.fitBounds(bounds, { padding: 55, maxZoom: 14, duration: 0 });
        }
      });
    })();
    return () => { cancelled = true; map?.remove(); };
  }, [center, routeCoordinates, stops]);

  return (
    <div className="location-map-shell">
      <div ref={container} className="map-host location-map-host" aria-label={`${label} ${lang === "KR" ? "지도" : "map"}`} />
      {!center && <div className="map-loading">{lang === "KR" ? "목적지 좌표를 확인하는 중…" : "Locating your destination…"}</div>}
      <div className="location-map-label glass"><b>{label}</b><span>{lang === "KR" ? "실제 지도 기반" : "Live map context"}</span></div>
    </div>
  );
}
