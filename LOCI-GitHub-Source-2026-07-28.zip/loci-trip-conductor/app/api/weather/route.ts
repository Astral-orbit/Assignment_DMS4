import { env } from "cloudflare:workers";

const weatherText: Record<number, { ko: string; en: string }> = {
  0: { ko: "맑음", en: "Clear" },
  1: { ko: "대체로 맑음", en: "Mostly clear" },
  2: { ko: "구름 조금", en: "Partly cloudy" },
  3: { ko: "흐림", en: "Overcast" },
  45: { ko: "안개", en: "Fog" },
  48: { ko: "짙은 안개", en: "Rime fog" },
  51: { ko: "약한 이슬비", en: "Light drizzle" },
  53: { ko: "이슬비", en: "Drizzle" },
  55: { ko: "강한 이슬비", en: "Heavy drizzle" },
  61: { ko: "약한 비", en: "Light rain" },
  63: { ko: "비", en: "Rain" },
  65: { ko: "강한 비", en: "Heavy rain" },
  71: { ko: "약한 눈", en: "Light snow" },
  73: { ko: "눈", en: "Snow" },
  75: { ko: "강한 눈", en: "Heavy snow" },
  80: { ko: "약한 소나기", en: "Light rain showers" },
  81: { ko: "소나기", en: "Rain showers" },
  82: { ko: "강한 소나기", en: "Heavy rain showers" },
  95: { ko: "뇌우", en: "Thunderstorm" },
  96: { ko: "우박을 동반한 뇌우", en: "Thunderstorm with hail" },
  99: { ko: "강한 우박성 뇌우", en: "Severe thunderstorm with hail" },
};

type GoogleWeatherResponse = {
  currentTime?: string;
  weatherCondition?: { description?: { text?: string }; type?: string };
  temperature?: { degrees?: number };
  feelsLikeTemperature?: { degrees?: number };
  relativeHumidity?: number;
  uvIndex?: number;
  precipitation?: {
    qpf?: { quantity?: number };
    probability?: { percent?: number; type?: string };
  };
  wind?: {
    direction?: { cardinal?: string; degrees?: number };
    speed?: { value?: number };
    gust?: { value?: number };
  };
  visibility?: { distance?: number };
  cloudCover?: number;
};

const jsonHeaders = { "Cache-Control": "public, max-age=300, s-maxage=600" };

export async function GET(request: Request) {
  const url = new URL(request.url);
  const lat = Number(url.searchParams.get("lat"));
  const lng = Number(url.searchParams.get("lng"));
  const languageCode = url.searchParams.get("lang") === "EN" ? "en" : "ko";
  if (!Number.isFinite(lat) || lat < -90 || lat > 90 || !Number.isFinite(lng) || lng < -180 || lng > 180) {
    return Response.json({ error: "Invalid coordinates" }, { status: 400 });
  }

  const bindings = env as typeof env & {
    GOOGLE_WEATHER_API_KEY?: string;
    GOOGLE_MAPS_API_KEY?: string;
  };
  const googleKey = bindings.GOOGLE_WEATHER_API_KEY || bindings.GOOGLE_MAPS_API_KEY;
  let googleError = "";

  if (googleKey) {
    try {
      const google = new URL("https://weather.googleapis.com/v1/currentConditions:lookup");
      google.searchParams.set("key", googleKey);
      google.searchParams.set("location.latitude", String(lat));
      google.searchParams.set("location.longitude", String(lng));
      google.searchParams.set("unitsSystem", "METRIC");
      google.searchParams.set("languageCode", languageCode);
      const response = await fetch(google);
      if (!response.ok) {
        googleError = `Google Weather returned ${response.status}`;
      } else {
        const data = await response.json() as GoogleWeatherResponse;
        const temp = data.temperature?.degrees;
        if (typeof temp !== "number") throw new Error("Google Weather omitted temperature");
        return Response.json({
          temp,
          feels: data.feelsLikeTemperature?.degrees ?? temp,
          condition: data.weatherCondition?.description?.text || data.weatherCondition?.type || (languageCode === "ko" ? "현재 날씨" : "Current weather"),
          humidity: data.relativeHumidity ?? null,
          precipitationProbability: data.precipitation?.probability?.percent ?? null,
          precipitationAmount: data.precipitation?.qpf?.quantity ?? null,
          precipitationType: data.precipitation?.probability?.type ?? null,
          windSpeed: data.wind?.speed?.value ?? null,
          windGust: data.wind?.gust?.value ?? null,
          windDirection: data.wind?.direction?.cardinal ?? null,
          uvIndex: data.uvIndex ?? null,
          visibility: data.visibility?.distance ?? null,
          cloudCover: data.cloudCover ?? null,
          observedAt: data.currentTime ?? null,
          source: "Google Weather API",
        }, { headers: jsonHeaders });
      }
    } catch (error) {
      googleError = error instanceof Error ? error.message : "Google Weather request failed";
    }
  }

  try {
    const fallback = new URL("https://api.open-meteo.com/v1/forecast");
    fallback.searchParams.set("latitude", String(lat));
    fallback.searchParams.set("longitude", String(lng));
    fallback.searchParams.set("current", "temperature_2m,apparent_temperature,relative_humidity_2m,precipitation,weather_code,wind_speed_10m,wind_gusts_10m,wind_direction_10m,cloud_cover");
    fallback.searchParams.set("timezone", "auto");
    const response = await fetch(fallback);
    if (!response.ok) throw new Error(`Open-Meteo returned ${response.status}`);
    const data = await response.json() as {
      current?: {
        time?: string;
        temperature_2m?: number;
        apparent_temperature?: number;
        relative_humidity_2m?: number;
        precipitation?: number;
        weather_code?: number;
        wind_speed_10m?: number;
        wind_gusts_10m?: number;
        wind_direction_10m?: number;
        cloud_cover?: number;
      };
    };
    const temp = data.current?.temperature_2m;
    if (typeof temp !== "number") throw new Error("Open-Meteo omitted temperature");
    const code = data.current?.weather_code ?? 0;
    const condition = weatherText[code] || { ko: "현재 날씨", en: "Current weather" };
    return Response.json({
      temp,
      feels: data.current?.apparent_temperature ?? temp,
      condition: languageCode === "ko" ? condition.ko : condition.en,
      humidity: data.current?.relative_humidity_2m ?? null,
      precipitationProbability: null,
      precipitationAmount: data.current?.precipitation ?? null,
      precipitationType: null,
      windSpeed: data.current?.wind_speed_10m ?? null,
      windGust: data.current?.wind_gusts_10m ?? null,
      windDirection: data.current?.wind_direction_10m ?? null,
      uvIndex: null,
      visibility: null,
      cloudCover: data.current?.cloud_cover ?? null,
      observedAt: data.current?.time ?? null,
      source: "Open-Meteo fallback",
      googleStatus: googleKey ? googleError || "Google Weather unavailable" : "Google Weather API key is not configured",
    }, { headers: jsonHeaders });
  } catch {
    return Response.json({
      error: "Weather is temporarily unavailable",
      googleStatus: googleKey ? googleError || "Google Weather unavailable" : "Google Weather API key is not configured",
    }, { status: 503 });
  }
}
