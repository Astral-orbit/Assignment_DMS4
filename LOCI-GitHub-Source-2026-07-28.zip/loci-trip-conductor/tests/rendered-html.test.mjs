import assert from "node:assert/strict";
import { access, readFile } from "node:fs/promises";
import test from "node:test";

const read = (path) => readFile(new URL(path, import.meta.url), "utf8");

test("starts with user-supplied trip data instead of a fabricated profile", async () => {
  const app = await read("../app/travel-app.tsx");
  assert.match(app, /destination:\s*""[\s\S]*accommodation:\s*""[\s\S]*people:\s*1[\s\S]*dates:\s*""[\s\S]*purpose:\s*""[\s\S]*styles:\s*\[\]/);
  assert.doesNotMatch(app, /Daehui|seedPosts|댓글 8|8 comments|서울, 대한민국/);
  assert.match(app, /GUEST SESSION|게스트 세션/);
});

test("requests localized map data and labels source-language fallbacks", async () => {
  const [app, geocode, places] = await Promise.all([
    read("../app/travel-app.tsx"),
    read("../app/api/geocode/route.ts"),
    read("../app/api/places/route.ts"),
  ]);
  assert.match(app, /api\/geocode\?q=.*&lang=/);
  assert.match(geocode, /Accept-Language/);
  assert.match(places, /namedetails/);
  assert.match(places, /translationStatus/);
  assert.match(app, /Source language|원문 표기/);
});

test("does not fabricate AI, review, or community data on failures", async () => {
  const [plan, posts, reviews] = await Promise.all([
    read("../app/api/plan/route.ts"),
    read("../app/api/posts/route.ts"),
    read("../app/api/reviews/route.ts"),
  ]);
  assert.doesNotMatch(plan, /demoPlan|central Seoul|demo intelligence/);
  assert.match(plan, /status:\s*503/);
  assert.match(posts, /editTokenHash/);
  assert.match(posts, /status:\s*403/);
  assert.match(reviews, /status:\s*503/);
});

test("connects localized current conditions to the trip weather panel", async () => {
  const [app, weather] = await Promise.all([
    read("../app/travel-app.tsx"),
    read("../app/api/weather/route.ts"),
  ]);
  assert.match(weather, /weather\.googleapis\.com\/v1\/currentConditions:lookup/);
  assert.match(weather, /languageCode/);
  assert.match(weather, /GOOGLE_WEATHER_API_KEY/);
  assert.match(weather, /Open-Meteo fallback/);
  assert.match(app, /api\/weather\?lat=.*&lang=/);
  assert.match(app, /weather-strip/);
  assert.match(app, /Humidity|습도/);
});

test("packages the community ownership migration", async () => {
  const migration = await read("../drizzle/0001_loud_silvermane.sql");
  assert.match(migration, /edit_token_hash/);
  await access(new URL("../dist/.openai/drizzle/0001_loud_silvermane.sql", import.meta.url));
});

test("builds a hotel round-trip day with meal, cafe, culture, and evening rules", async () => {
  const [app, places, routes] = await Promise.all([
    read("../app/travel-app.tsx"),
    read("../app/api/places/route.ts"),
    read("../app/api/routes/route.ts"),
  ]);
  assert.match(app, /Booked accommodation name or address/);
  assert.match(app, /pick\(groups\.restaurants,\s*"08:00"/);
  assert.match(app, /pick\(groups\.restaurants,\s*"12:00"/);
  assert.match(app, /pick\(groups\.cafes,\s*"14:30"/);
  assert.match(app, /pick\(groups\.restaurants,\s*"18:00"/);
  assert.match(app, /scheduledTime:\s*"23:00"/);
  assert.match(app, /exclude:\s*\["parks",\s*"museums"\]/);
  assert.match(app, /cuisineKey/);
  assert.match(app, /isOpenAt/);
  assert.match(places, /regularOpeningHours/);
  assert.match(places, /locationRestriction/);
  assert.match(places, /places:searchNearby/);
  assert.match(routes, /slice\(0,\s*12\)/);
});

test("shows every filtered Explore venue on the map and supports marker selection", async () => {
  const [app, maps] = await Promise.all([
    read("../app/travel-app.tsx"),
    read("../app/world-maps.tsx"),
  ]);
  assert.match(app, /const exploreMapStops = useMemo\(\(\) => mapStops\(activePlaces\)/);
  assert.match(app, /stops=\{exploreMapStops\}/);
  assert.match(app, /onSelectStop=\{id =>/);
  assert.match(maps, /map\.on\("click", "trip-route-points"/);
  assert.match(maps, /properties:\s*\{\s*kind:\s*"stop",\s*id:/);
});

test("spreads discovery across the destination and deprioritizes likely chains", async () => {
  const [app, geocode, places] = await Promise.all([
    read("../app/travel-app.tsx"),
    read("../app/api/geocode/route.ts"),
    read("../app/api/places/route.ts"),
  ]);
  assert.match(geocode, /boundingbox/);
  assert.match(app, /bounds:\s*data\.bounds/);
  assert.match(app, /regionalAnchors/);
  assert.match(app, /place\.isLikelyChain\s*\?\s*-12/);
  assert.match(places, /regionCenters/);
  assert.match(places, /diverseSlice/);
  assert.match(places, /knownChainTokens/);
  assert.match(places, /repeated-brand-name/);
  assert.match(places, /Instagram Graph API/);
  assert.match(places, /ig_hashtag_search/);
  assert.match(places, /top_media/);
  assert.match(places, /INSTAGRAM_ACCESS_TOKEN/);
});
