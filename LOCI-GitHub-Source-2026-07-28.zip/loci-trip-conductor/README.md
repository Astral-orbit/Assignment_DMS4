# LOCI — AI Trip Conductor

지도·장소·교통·날씨 데이터를 결합해 실제 목적지에 맞는 여행 일정과 이동 동선을 추천하는 풀스택 여행 플래너입니다.

LOCI is a full-stack travel planner that combines maps, places, transit, and weather data to recommend destination-specific itineraries and routes.

## 주요 기능 · Highlights

- 한국어/영어 전환과 목적지·숙소·날짜·인원·여행 스타일 설문
- 실제 장소 기반 PLAN A/B/C 추천과 숙소 출발·복귀 일정
- 식사, 카페, 문화시설, 공원, 야간 방문 시간 규칙
- Google Places 별점, 리뷰, 영업시간과 로컬 우선 추천
- Google Routes 대중교통 소요시간, 거리, 환승, 정거장과 제공 가능한 요금
- Google Weather 기반 현재 날씨와 여행 코디 안내
- MapLibre 지도 위 장소 마커와 플랜별 경로 시각화
- 목적지별 리뷰와 세계지도 기반 커뮤니티
- Korean/English UI, real-place recommendations, transit routing, live weather, maps, reviews, and destination communities

## 기술 구성 · Stack

- Next.js 16, React 19, TypeScript
- vinext and Cloudflare Workers
- MapLibre GL
- Cloudflare D1 and Drizzle ORM
- Google Places API (New), Routes API, Geocoding API, Weather API
- OpenStreetMap, Nominatim, Overpass, and OSRM fallbacks

## 로컬 실행 · Local development

Node.js `>=22.13.0`이 필요합니다.

```bash
npm install
cp .env.example .env.local
npm run dev
```

Open `http://localhost:3000` or the URL printed by the development server.

## 환경 변수 · Environment variables

```dotenv
GOOGLE_MAPS_API_KEY=
GOOGLE_WEATHER_API_KEY=
OPENROUTER_API_KEY=
INSTAGRAM_ACCESS_TOKEN=
INSTAGRAM_USER_ID=
INSTAGRAM_GRAPH_API_VERSION=v23.0
```

- `GOOGLE_MAPS_API_KEY` enables Places, Routes, Geocoding, and Weather unless a separate weather key is supplied.
- Enable Places API (New), Routes API, Geocoding API, and Weather API in the same Google Cloud project.
- Restrict production keys to only the required APIs and configure quotas. Never commit real keys.
- Instagram variables are optional and require an authorized Instagram Graph API account.
- Without optional providers, LOCI clearly labels and uses OpenStreetMap/OSRM fallbacks instead of inventing data.

## 검증 · Validation

```bash
npm run lint
npm test
npm run build
```

## 데이터 투명성 · Data transparency

- Google Places API (New) returns at most five relevance-ranked reviews per place. LOCI marks which returned reviews were published within the last 30 days; it does not claim to provide the complete monthly review history.
- Transit fares are displayed only when Google Routes supplies them.
- Missing ratings, reviews, fares, temperatures, and account activity are shown as unavailable rather than filled with synthetic values.
- 사용자 작성 리뷰와 커뮤니티 글은 D1에 저장됩니다.

## 배포 · Deployment

The project builds to a Cloudflare Worker-compatible vinext output. Runtime secrets must be configured in the hosting environment rather than committed to the repository.

현재 배포: [LOCI — AI Trip Conductor](https://loci-trip-conductor.astrally1022.chatgpt.site)
